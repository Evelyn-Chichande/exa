import { Component } from '@angular/core';

@Component({
  selector: 'app-mi-api',
  standalone: true,
  imports: [],
  templateUrl: './mi-api.component.html',
  styleUrl: './mi-api.component.css'
})
export class MiApiComponent {

}
